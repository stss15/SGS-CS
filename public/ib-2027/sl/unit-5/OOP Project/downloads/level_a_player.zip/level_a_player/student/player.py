class Player:

    # CONSTRUCTOR
    def __init__(self, name: str):
        pass

    # GET STARTING STATS
    def get_starting_stats(self) -> dict:
        """
        Returns:
            A dictionary with keys: health, max_health, armour, accuracy
        """
        pass

    # GET STATUS
    def get_status(self) -> str:
        """
        Returns:
            A string like "Alice: 85/100 HP"
        """
        pass

    # TAKE DAMAGE
    def take_damage(self, amount: int) -> None:
        pass

    # HEAL
    def heal(self, amount: int) -> None:
        pass
